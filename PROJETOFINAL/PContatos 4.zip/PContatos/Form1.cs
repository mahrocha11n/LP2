﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContatos
{
    public partial class Form1 : Form
    {
        public static SqlConnection conn;
        public Form1()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            
            try
            {
                conn = new SqlConnection("Data Source=APOLO;Initial Catalog=BD;User ID=BD2511033;PASSWORD=Allstarverde19");
                conn.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros erros =/" + ex.Message);
            }
        }

        private void cadastroTelefoneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato objC = new frmContato();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre objC = new frmSobre();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }
    }
}
