﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContatos
{
    public partial class frmPrincipal_Load : Form
    {
        public frmPrincipal_Load()
        {
            InitializeComponent();
        }
    }
}
