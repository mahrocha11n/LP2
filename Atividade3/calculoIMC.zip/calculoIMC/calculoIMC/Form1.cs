﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculoIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtIMC.Clear();
            txtPeso.Clear();

        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            if((!double.TryParse(txtPeso.Text, out peso) ||
            (!double.TryParse(txtAltura.Text, out altura))))
            {
                MessageBox.Show("Dados inválidos");
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);
                imc= Math.Round(imc,1);
                txtIMC.Text = imc.ToString();
                if (imc<18.5)
                {
                    MessageBox.Show("Sua classificação é: magreza e nível de obesidade 0");
                }
                else if (imc <=24.9)
                {
                    MessageBox.Show("Sua classificação é: normal e nível de obesidade 0");
                }
                else if (imc <= 29.9)
                {
                    MessageBox.Show("Sua classificação é: sobrepeso e nível de obesidade 1");
                }
                else if(imc <= 39.9)
                {
                    MessageBox.Show("Sua classificação é: obesidade e nível de obesidade 2");
                }
                else
                {
                    MessageBox.Show("Sua classificação é: obesidade severa e nível de obesidade 3");
                }
            }
            

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult= MessageBox.Show("Você tem certeza que quer sair","Confirmação" );
        }
    }
}
