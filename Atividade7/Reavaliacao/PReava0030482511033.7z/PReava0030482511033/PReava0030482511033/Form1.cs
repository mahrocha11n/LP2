﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PReava0030482511033
{
    public partial class Form1 : Form
    {
        double N = 1.5;
        double[] MatrizA = new double[9];
        double[] MatrizB = new double[9];
        private object listbox1;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            for (int i =0;i<10;i++)
                MatrizA[i] = N * (i + 1);
            for (int i = 0; i < 10; i++)
            {
                if (MatrizA[i] / 2 == 0)
                {
                    MatrizB[i] = MatrizA[i] * 4;
                }
                if (MatrizA[i] / 2 != 0)
                {
                    MatrizB[i] = MatrizA[i] + 4;
                }
            }
        }
           /* for (int i = 0; i <10; i++)
            {
                List.Show($"Posição:"+i+" Matriz A=" + MatrizA[i,0] +"Matriz B=" + MatrizB[i]);

            }
        }*/

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                MessageBox.Show($"Posição:" + i + " Matriz A=" + MatrizA[i] + "Matriz B=" + MatrizB[i]);

            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            listbox1.Clear();
        }
    }
 }

